<pre>
<?=isset($data)&&print_r($data);?>
</pre>
