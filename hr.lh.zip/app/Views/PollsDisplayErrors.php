<div class="mt-3 mb-3 callout callout-error">
    <?=$message??""?>
</div>
