<?php if(isset($apps)) foreach ($apps as $day=>$appByDays):?>
<table class="table table-striped caption-top align-middle" style="table-layout: fixed;">
    <caption class="fs-5 text-primary fw-bold"><?=$day?></caption>
    <thead class="table-caption">
        <tr>
            <td>опрос</td>
            <td style="width: 50px">#</td>
            <td>Дата</td>
            <td>Имя</td>
            <td>Email</td>
            <td>Телефон</td>
            <td style="width: 300px"></td>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($appByDays as $app):?>
            <tr>
                <td>
                    <?=isset($polls[$app->poll_id])?$polls[$app->poll_id]->name:"Не действителен #$app->poll_id"?>
                </td>
                <td><?=$app->id?></td>
                <td><?=$app->time?></td>
                <td><?=$app->name?></td>
                <td><?=$app->email?></td>
                <td><?=$app->phone?></td>
                <td>btn</td>
            </tr>
        <?php endforeach;?>
    </tbody>
</table>
<?php endforeach;?>
